
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'populateFields') {
        // Retrieve data from chrome.storage.local
        chrome.storage.local.get('formData', (data) => {
            const fields = data.formData || {};
            console.log('Retrieved Data:', fields); // Debugging line

            Object.entries(fields).forEach(([name, value]) => {
                try {
                    // Find element by id or name
                    let element = document.querySelector(`[id="${name}"], [name="${name}"]`);

                    if (element) {
                        console.log(`Found element: ${element.tagName} with id or name "${name}"`);

                        if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
                            // Populate input fields and textareas
                            element.value = value;
                            // Create and dispatch events
                            const event = new Event('change', { bubbles: true });
                            element.dispatchEvent(event);
                            console.log(`Set value for ${name} to ${value}`); // Debugging line

                        } else if (element.tagName === 'SELECT') {
                            // Populate dropdowns (select elements)
                            const options = element.querySelectorAll('option');
                            let optionFound = false;

                            options.forEach(option => {
                                if (option.value === value) {
                                    option.selected = true;
                                    optionFound = true;
                                    console.log(`Set dropdown ${name} to ${value}`); // Debugging line
                                }
                            });

                            if (!optionFound) {
                                console.log(`Option value "${value}" not found in dropdown "${name}".`);
                            }
                            // Create and dispatch events
                            const changeEvent = new Event('change', { bubbles: true });
                            element.dispatchEvent(changeEvent);

                        } else {
                            console.log(`Element with id or name "${name}" is not an input field or select.`);
                        }
                    } else {
                        console.log(`Element with id or name "${name}" not found by id or name. Checking data-bind...`);

                        // Check for elements with class "form-control input-sm" and specific data-bind attribute
                        const elements = document.querySelectorAll('.form-control.input-sm[data-bind]');

                        let found = false;

                        elements.forEach(el => {
                            const dataBind = el.getAttribute('data-bind');
                            const classNames = el.getAttribute('class');
                            // const regex = new RegExp(`value:\\s*${name}`, 'i');
                            // Check if the data-bind or class names attribute contains the name in any format
                            const classNameMatch = classNames.split(" ")[classNames.split(" ").length - 1] == (name + "-undefined")
                            const dataBindMatch = dataBind.includes(name) // dataBind && regex.test(dataBind)
                            if (classNameMatch || dataBindMatch) {
                                found = true;
                                if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
                                    el.value = value;
                                    console.log(`Set value for ${name} with data-bind to ${value}`);
                                    // Create and dispatch events
                                    const event = new Event('change', { bubbles: true });
                                    el.dispatchEvent(event);
                                } else if (el.tagName === 'SELECT') {
                                    const options = el.querySelectorAll('option');
                                    let optionFound = false;

                                    options.forEach(option => {
                                        if (option.value === value) {
                                            option.selected = true;
                                            optionFound = true;
                                            console.log(`Set dropdown ${name} with data-bind to ${value}`);
                                        }
                                    });

                                    if (!optionFound) {
                                        console.log(`Option value "${value}" not found in dropdown "${name}" with data-bind.`);
                                    }
                                    // Create and dispatch events
                                    const changeEvent = new Event('change', { bubbles: true });
                                    el.dispatchEvent(changeEvent);
                                }
                            }
                        });

                        if (!found) {
                            console.log(`No element with class "form-control input-sm" and data-bind/class containing value "${name}" found.`);
                        }
                    }
                } catch (error) {
                    console.error(`Error processing field "${name}":`, error);
                }
            });
        });
    }
});

