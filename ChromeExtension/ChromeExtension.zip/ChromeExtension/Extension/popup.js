// popup.js
document.addEventListener('DOMContentLoaded', () => {
    const fileInput = document.getElementById('fileInput');

    // Listen for changes on the file input
    fileInput.addEventListener('change', handleFileSelect);
});

function handleFileSelect(event) {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            const xmlData = e.target.result;
            // Parse the XML and send data to the background script
            parseAndSendData(xmlData);
        };
        reader.readAsText(file);
    }
}

function parseAndSendData(xmlData) {
    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(xmlData, "application/xml");
    const fields = xmlDoc.getElementsByTagName("Field");

    const formData = {};
    for (let i = 0; i < fields.length; i++) {
        const field = fields[i];
        const fieldName = field.getAttribute("FieldName");
        const fieldValue = field.getAttribute("FieldValue");
        formData[fieldName] = fieldValue;
    }

    // Save data in chrome storage and notify the background script
    chrome.storage.local.set({ formData }, () => {
        chrome.runtime.sendMessage({ action: 'populateFields', formData });
    });
}
